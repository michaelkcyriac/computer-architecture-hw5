#define _GNU_SOURCE
#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <assert.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>//for strstr and strcpy
#include <ctype.h> //for tolower


int main(int argc, char* argv[]) {

    char *str = NULL; // the big string we are looking at
    char cop_str[257];//the extra copy of str whos casing we will change to all lowecase if needed

    size_t len;


    if (stdin ==NULL)
        return 0;

    while((getline(&str, &len, stdin)) != EOF){    //(variable, 257 , wherer to get from(keyboard))

    // feof
        //doing for case insensative (the capatalization doesnt matter)
        if(strcmp (argv[1], "-i") == 0){

                //here the substring we are looking for is argv[2]

            strcpy(cop_str, str);

            for(int i=0; i<= strlen(cop_str); i++){
 
                cop_str[i]= tolower(cop_str[i]);
            }

            // also make sure the key is lower
            for(int i =0 ; i <= strlen(argv[2]) ; i++){

                argv[2][i] = tolower(  argv[2][i]  );
            }

            if(strstr(  cop_str, argv[2]   )){

                //puts(str);
                printf("%s", str);
                //puts(str);
            }


            
        }
        else if (strstr(str, argv[1])){ // the arg[1] is the substring we are looking for 
            //seems like strstr is case sensative

            //puts(str); //print out the word
            
            printf("%s", str);
        }




         
    }
    //works but get a new line at the end and was fixed
    
    /*while((fgets(str, sizeof(str), stdin)) != NULL){    //(variable, 257 , wherer to get from(keyboard))

    // feof
        str[strcspn(str, "\n")] = 0;

        //doing for case insensative (the capatalization doesnt matter)
        if(strcmp (argv[1], "-i") == 0){

                //here the substring we are looking for is argv[2]

            strcpy(cop_str, str);

            for(int i=0; i<= strlen(cop_str); i++){
 
                cop_str[i]= tolower(cop_str[i]);
            }

            // also make sure the key is lower
            for(int i =0 ; i <= strlen(argv[2]) ; i++){

                argv[2][i] = tolower(  argv[2][i]  );
            }

            if(strstr(  cop_str, argv[2]   )){

                puts(str);
            }


            
        }
        else if (strstr(str, argv[1])){ // the arg[1] is the substring we are looking for 
            //seems like strstr is case sensative

            puts(str); //print out the word
        }




         
    }*/
       free(str);
    
    return 0;

}

/*
        WORKS FOR THE CASE SENSATIVE ONE

        char str[257]; // the big string we are looking at
    
    

    while((fgets(str, sizeof(str), stdin)) != NULL){    //(variable, 257 , wherer to get from(keyboard))

    // feof
        //doing for case insensative (the capatalization doesnt matter)



        if(strstr(str, argv[1])){ // the arg[1] is the substring we are looking for 
            //seems like strstr is case sensative

            puts(str); //print out the word
        } 
    }
       
    
    return 0;
*/
/*
BEST TO TAKE IN AND SPIT OUT SOMTHING IMMEDIATILY UNITL CTRL D
int c;

    

    while((c = getchar()) != EOF){ //recieves the input from user and puts in c 
        //EOF means end of File which here is ctrl D
        
         putchar((c)); //displays c on the monitor
      


    }


*/





    /*feof(stdn)
    while(!feof(stdin)){ //feof checks if ^D is pressed

        scanf()
        if (feof(0))
            break

    }

    //or
    int n= scanf("%d %d", ..)
    while(n>0) //return 0 meaning got nothing
    //process string
    n= scanf();*/


/*
int main(int argc, char* argv[]) {

    argv[1] //what we search

    char string[256];

    scanf("%s",string);

    
    while(what represents ctrl D){

        printf("%s", string);
        scanf("%s", string);

    }
}


*/

