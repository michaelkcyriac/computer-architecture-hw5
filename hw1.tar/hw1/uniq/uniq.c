#define _GNU_SOURCE
#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <assert.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>//for strstr and strcpy
#include <ctype.h> //for tolower

int main(int argc, char* argv[]) {


char *str =NULL; //the current string they just inputed

  
    char **ary = malloc(1 * sizeof(char*)); //put all the string in here then sort it
    
    // char ary[number of string][max size of string]
    int index = 0; //highest number an index can be
    size_t len;
    

     while((getline(&str, &len, stdin)) != EOF){  
    
       //strcpy(ary[index] , curr);
        if(index == 0)
        { 
            
            ary[index] = malloc(len *sizeof(char));
         
            strcpy(ary[index] , str);
        }
        else{


            ////////////////////////top is old
            ary = realloc(ary, (index + 1) * sizeof(char*) );
            ary[index] = malloc(len *sizeof(char)); //len as in the length of the string
         
            strcpy(ary[index] , str);

        }

        index = index + 1;
    
    }
    //index--;
    index = index-1;
    

    int occ = 1 ; //number of times the unique word appears
    //the printing part
    //printf("%d \n", index);
    for(int i =0 ; i < (index+1) ;  i++){

       // printf("%d", i);

        // if(    (i+1) > index){
        //     printf("%d %s" , occ , ary[i]);
        //     occ = 1;

        // }
        // else 
        //  if (i+1) > index  || !strstr(ary[i] , ary[i+1]
        // if(  ary[i+1] == NULL || !strstr(ary[i] , ary[i+1]) 
        if(  i+1 > index) {  //index is the highest index that can be checked

            printf("%d %s" , occ , ary[i]);
            occ = 1;



        }
        else if(    i < (index+1)  && !strstr(ary[i] , ary[i+1])  ){

            printf("%d %s" , occ , ary[i]);
            occ = 1;
            
        }
        else {
            occ++;

        }
    }



    /////////////////////////////FREE EVERYTHING
    for ( int i=0; i< (index+1) ; i++ ) {
        free( ary[i] );
    }
    free(ary);
    free(str);

    return 0;


} //closing for main
