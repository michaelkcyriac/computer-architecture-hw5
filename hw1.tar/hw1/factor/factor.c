#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <assert.h>
#include <stdbool.h>
#include <math.h>

//have to make a program that takes a number
//and return the prime factors excluding 1
//if the number itself id prime just return it by itself

bool isPrime(int num);

int main(int argc, char* argv[]) {

    int num = atoi(argv[1]); //take the number that is initially a string and makes it a int

    if(isPrime(num)){

        printf("%d\n", num);
        return 0;    //should stop the program if it prime
    }
  /*  
        THIS CANT DO repete answer like if 32 is entered it doesnt give 2 * 2 *  2 * 2 *2 only gives 2

    

    for(int i = 2; i<= (num) ; i++ ){

        if((num % i) == 0 && isPrime(i)){

            printf("%d ", i);
        }

    }
    */
    //going to try a prime factorization look at youtube(the thing that looks like a ladder)
    int i = 2;

    while(num !=1){// you stop the factorization thing at 1

        if((num % i) == 0 && isPrime(i)){

            while((num%i) ==0){ // the num = num/i should do print 2 then num = 16 then num =8 then 4 then 2 then 1

                 
                 num = (num/i);
                 if(num == 1){

                     printf("%d\n" , i);
                 }
                 else{
                     printf("%d ", i);
                 }

            }             
        }
        i++;
    }//while closing


    return 0;


}

bool isPrime(int num){

    for(int i=2; i <= sqrt(num) ; i++){

        if((num % i) == 0){// if there is an int divided by the number that doesnt create a remainder it has a factor
                            // so it isnt prime
            return false;
        }
    }
    return true;


}