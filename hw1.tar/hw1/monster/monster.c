#define _GNU_SOURCE
#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <assert.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>//for strstr and strcpy
#include <ctype.h> //for tolower

int main(int argc, char* argv[]) {

    

    ////////  THE ARGUMENTS that gets assigned
    bool done = false;
    //char str ;
    char *str =NULL;
    bool valid= true; //player made a valid move then true
    

    int boardX = atoi(argv[1]);          //Number of squares in x direction
    int boardY = atoi(argv[2]);          //Number of squares in y direction

    int plrX = atoi(argv[3]);            //Player x starting position
    int plrY = atoi(argv[4]);            //Player y starting position
    
    int goalX = atoi(argv[5]);           //Goal x location
    int goalY = atoi(argv[6]);           //Goal y location

    int monX = atoi(argv[7]);            //Monster x starting position
    int monY = atoi(argv[8]);            //Monster y starting position


    char** matrix = malloc( boardY * sizeof(char*) ); //rows make

    for ( int i=0; i<boardY; i++ ) { //cols make 
        matrix[i] = malloc( boardX * sizeof(char) );
    }

    // initializing the matrix and adding a '.' to all of them
    for ( int i=0; i<boardY; i++ ) {
        for( int j=0; j<boardX;j++){
            
            matrix[i][j] = '.';
        }
    }
                    ///doing the board -1)  - playerY helps a matrix thats set up like the 1st quadrant of a graph
    matrix[ (boardY-1) -plrY ][plrX] = 'P';    

    matrix[ (boardY-1) - goalY] [goalX] = 'G';

    matrix[ (boardY-1) -monY] [monX] = 'M';

    //printing out the matrix map thing

    for(int i =0; i<boardY;i++){
        for(int j = 0; j<boardX ; j++)
            if(j == boardX -1)
                printf("%c", matrix[ i][j]); //all the wayright ones have no space after the "."
            else
                printf("%c ", matrix[ i][j]);

    
        printf("\n");
    }
    size_t len;

    //fscanf(stdin , "  %c " , &direc );
    while(!done && getline(&str, &len, stdin) != EOF){
       
        //scanf("%c", &str);
        
        //printf("entered E");
        ///////movnig the player
        valid = true;
        


        if( *str == 'N'  && (plrY+1) < boardY  ){

            matrix[ (boardY-1) -plrY ][plrX] = '.'; 

            plrY = plrY +1;

            matrix[ (boardY-1) -   plrY ][plrX] = 'P';


        }else if(*str == 'S' && (plrY  - 1) > -1  ){

            matrix[ (boardY-1) - plrY ][plrX] = '.'; 

            plrY = plrY - 1;

            matrix[ (boardY-1) -   plrY ][plrX] = 'P';

        }else if(*str == 'E' && (plrX +1) <boardX  ){ // if the boradX = 5 then pleyX can be 0- 4

            matrix[ (boardY-1) -plrY ][plrX] = '.';

            plrX = plrX +1;

            matrix[ (boardY-1) -   plrY ][plrX] = 'P';
            //printf("entered E");

        }else if(*str == 'W' && (plrX - 1) > -1  ){

            matrix[ (boardY-1) -plrY ][plrX] = '.'; 

            plrX = plrX -1;

            matrix[ (boardY-1) -   (plrY) ][plrX] = 'P';
        }
        else { //else if( (plrX-1) <0 || (plrX+1) >= boardX || plrY < 0 || (plrY-1) < 0 || plrY+1 >= boardY || str != 'N' || str != 'E' || str != 'S' || str != 'W'  ){


            printf("invalid move\n");
            valid = false; //not a valid move they have to try again

        }///player movement done
        //printf(  "player x then Y; %d %d\n",plrX, plrY );

        if(valid){

            //if its vaid check if they got to the goal
            if( ((boardY-1) -plrY  ==  (boardY-1) - goalY) &&  plrX == goalX ){

                printf("player wins!\n");
                 done = true;
                
            }else if( ((boardY-1) -plrY ==(boardY-1) -monY)  && plrX == monX ){ // cheack if player intentionally lands on the monster and monster won

                printf("monster wins!\n");
                 done = true;
                
            }

           
        } //the one checking the players move caused a end to game

        if( !done  && valid){ //if its not ended and the player made a valid move that mean the monster can move

            // printf(" abs mony- plrY %d  and abs(monX - plrX; %d\n " , abs(monY - plrY), abs(monX - plrX ));
            // printf(  "after plr moves and before monster moves monster x then Y; %d %d\n",monX, monY ); 

            if(  abs((monY+1) - (plrY+1))  == abs((monX+1) - (plrX+1) ) ){// if distance Y =X abs(((boardY-1) -monY) - ((boardY-1) -plrY))  == abs(monX - plrX )  old dumb?

                //puts("test");

                if(monY > plrY ){//((boardY-1) -monY) - ((boardY-1) -plrY)  >= 0

                    matrix[ (boardY-1) - monY ][monX] = '.'; 

                    monY = monY - 1;

                    matrix[ (boardY-1) -   monY ][monX] = 'M';
                    printf("monster moves S\n");


                }else if( monY < plrY  ){ // ((boardY-1) -monY) - ((boardY-1) -plrY)  <0    old dumb?

                    matrix[ (boardY-1) - monY ][monX] = '.'; 

                    monY = monY + 1;

                    matrix[ (boardY-1) -   monY ][monX] = 'M';
                    printf("monster moves N\n");
                }

            } else if( abs((monY+1) - (plrY+1) )  > abs((monX+1) - (plrX+1) )){ //  { //if abs Y> abs X    abs(((boardY-1) -monY) - ((boardY-1) -plrY))  > abs(monX - plrX

                if( monY > plrY  ){//((boardY-1) -monY) - ((boardY-1) -plrY)  >=0 

                    matrix[ (boardY-1) - monY ][monX] = '.'; 

                    monY = monY - 1;

                    matrix[ (boardY-1) -   monY ][monX] = 'M';

                    printf("monster moves S\n");


                }else if(   monY < plrY    ){ // ((boardY-1) -monY) - ((boardY-1) -plrY)  <0

                    matrix[ (boardY-1) - monY ][monX] = '.'; 

                    monY = monY + 1;

                    matrix[ (boardY-1) -   monY ][monX] = 'M';// this is where the monster moves

                    printf("monster moves N\n");
                }
                

            }else if(   abs((monY+1) -  (plrY+1))  < abs((monX+1) - (plrX+1) )  ){//if Y<X    abs(((boardY-1) -monY) - ((boardY-1) -plrY))  < abs(monX - plrX ) 
                    // mony - plry
                    //if abs Y < abs X

                if( monX > plrX){  //(monX - plrX) >= 0

                    matrix[ (boardY-1) -monY ] [monX] = '.'; 

                    monX = monX -  1 ;

                    matrix[ (boardY-1) -   (monY) ][monX] = 'M';
                    printf("monster moves W\n");


                }else if(  monX < plrX    ){ //(monX - plrX) < 0 

                    matrix[ (boardY-1) -monY ][monX] = '.'; 

                    monX = monX +  1 ;

                    matrix[ (boardY-1) -   (monY) ][monX] = 'M';
                    printf("monster moves E\n");


                }
                //printf(  "after moster moves the monster x then Y; %d %d\n",monX, monY ); 
                


            }
            //// end of monster movement

            //printf(  "monster x then Y; %d %d\n",monX, monY );




            // checking if the done after monster movement
            if( ((boardY-1) -plrY ==(boardY-1) -monY)  && plrX == monX ){ // cheack if player intentionally lands on the monster and monster won

                printf("monster wins!\n");
                 done = true;
                
            }

        }











        /////////////////printing after each move
        if(!done && valid){
        for(int i =0; i<boardY;i++){
            for(int j = 0; j<boardX ; j++)
                if(j == boardX -1)
                    printf("%c", matrix[ i][j]); //all the wayright ones have no space after the "."
                else
                    printf("%c ", matrix[ i][j]);

    
            printf("\n");
            }
           
        }

        
        

    }//while loop closeing









/////////////////////////////////////////////////////////////////////////
    //free the matrix and evreything allocated
    //at the end of fullthing
    //free(str);
    for (int  i=0; i<boardY; i++ ) {
        free( matrix[i] );
    }
    free( matrix );
    return 0;

}