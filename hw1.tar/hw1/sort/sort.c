#define _GNU_SOURCE
#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <assert.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>//for strstr and strcpy
#include <ctype.h> //for tolower

int main(int argc, char* argv[]) {

    char *str =NULL; //the current string they just inputed

    //char *ary = (char*)malloc(1 * sizeof(char)); //put all the string in here then sort it
    char **ary = malloc(1 * sizeof(char*)); //put all the string in here then sort it
    
    // char ary[number of string][max size of string]
    int index = 0; //highest number an index can be
    size_t len;
    

    //strcmp == 0 then bother string are 0
    //if strcmp(A)(B) >0 then string A > string B
    //strcomp(there)(their)
    //the ascii value of r >i
    //so strA>str B

     while((getline(&str, &len, stdin)) != EOF){  
    
       //strcpy(ary[index] , curr);
        if(index == 0)
        { // ary = (char*)malloc(1 * sizeof(char));
            
            ary[index] = malloc(len *sizeof(char));
            //ary[index] = str;
            strcpy(ary[index] , str);
        }
        else{


            // ary = (char*)realloc(ary, (index + 1) * sizeof(char) );

            // ary[index] = *str;
            // // strcpy(&ary[index] , str);
            ////////////////////////top is old
            ary = realloc(ary, (index + 1) * sizeof(char*) );
            ary[index] = malloc(len *sizeof(char));
            //ary[index] = str;
            strcpy(ary[index] , str);

        }
        //printf("%s", ary[index]); //the print showed all the string are being stored correctly
        
        //index++;
        

        index = index + 1;
    
    }
    //index--;
    index = index-1;
/////////////////////////////////////////////////
//find the length of the longerst string
 int bistring = 257;

for(int i=0 ; i < (index+1) ; i++){

    if ( strlen(ary[i]) > bistring)
        bistring = strlen(ary[i]);

}
    
/////////////////////////////////////////////////////////////
    // the actual sorting part
    int F = 0;
    char **key = malloc(1 * sizeof(char*));
    key[F] = malloc(bistring *sizeof(char));
    //char temp[] ; 
    char **temp = malloc(1 * sizeof(char*));
    temp[F] = malloc(bistring *sizeof(char));
    
    if(argc == 2){ //if command line argument is ./sort -n
 //insetion sort
        for(int i =1 ; i <  (index +1) ; i++){

            //key[F] = ary[i]; //key == curr we are looking at
             strcpy(key[F] , ary[i]);
            int m = i-1;
            while(m >= 0 &&  atoi(ary[m]) > atoi(key[F] )      ){
            
                //temp[F] = ary[m+1]; //so that we dont lose the value of the string at ary[m+1]
                //ary[m+1] = ary[m];
                strcpy(ary[m+1] , ary[m]);
                //ary[m] = temp[F];
                m = m-1;
                // strcpy(temp[F] ,ary[m+1]);
                // strcpy(ary[m+1], ary[m]);
                // strcpy(ary[m] , temp[F]);
                // m=m+1;

            }
            //ary[m+1] = key[F];
             strcpy(ary[m+1], key[F]);
        }
    }
    else{ // if command line argument is ./sort
    // when there is no command line argument
    //doing lexicographic sorting

    for(int i= 0; i< (index+1); ++i){ //ignores casing
        for(int j = i+1;  j< index+1 ; ++j){


            if(strcasecmp(ary[i], ary[j])  > 0){ //strcasesmp(string ,string) compares while ignoreing casings

                strcpy(temp[F] ,ary[i]);
                strcpy(ary[i], ary[j]);
                strcpy(ary[j] , temp[F]);
            }
        }
    }}
    ///////////////////////////////////////////////////////////////////////

    //printing the sorted thing at the end of everything
    //i think prob here
    for( int j = 0; j < (index+1) ; j++){

        printf("%s", ary[j]);
        
    }

    //freeing everything

  
    
    for ( int i=0; i<index+1; i++ ) {
        free( ary[i] );
    }
    free( ary );

    free(key[F]);
    free(key);
    free(str);
    free(temp[F]);
    free(temp);
    
    // for(int i = 0 ; i <= index ; i++)
    //     free(ary[i]);
    return 0;

}

    /*

    char** string_array;

    int default_size = 10;

    string_array= (char**)malloc(default_size  * sizeof());

    for(int i =0; i<default_size ; i++){

        string_array[i] = (char*) malloc(256* sizeof)
    }
    int index = 0
    scanf("%s", string_array[index]);

    while(!ctrl D){
        if(index = default_size - 2){

            string_array = realloc ();
        }
        index++;
        scanf("%s", string_array[index]);
    }
    //sort now
    */
    
